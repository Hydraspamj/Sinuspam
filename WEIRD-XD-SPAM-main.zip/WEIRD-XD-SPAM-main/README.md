### 💥𝙎𝙄𝙉𝙐 𝙃𝘼𝙉💥

<!--
**itzshukla/itzshukla** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.


<p align="center">
    <b>ᴠɪsɪᴛᴏʀs</b><br>
 -->    <img align="middle" src="https://profile-counter.glitch.me/itszshivam/count.svg" />
</p>

<h1 align="center"><b> 𝙎𝙄𝙉𝙐𝙃𝘼𝙉 𝐗🔥</b></h1>

<h4 align="center"> 𝐓𝐇𝐄 𝐏𝐎𝐖𝐄𝐑𝐅𝐔𝐋 𝐒𝐏𝐀𝐌𝐁𝐎𝐓𝐒</h4>

<p align="center"><a href="https://t.me/shiva_ansh_op"><img src="https://telegra.ph/file/aa4bf1e57d11fb75b602e.jpg" width="400"></a></p>


> ⭐️ Thanks to everyone for using THIS STRANGER SPAM BOT, That is the greatest pleasure we have !

<br>

- ⚠️ Do not forget to fork this repo. Else error can occur in deployment.

# ᴅᴇᴘʟᴏʏᴍᴇɴᴛ


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ</b></summary>
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/Sinuhann/Bloddxpoisan.git)
  
</details>


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ᴋᴏʏᴇʙ</b></summary>
<br>

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=&branch=name&name=thealtron)
  
</details>


# Rᴇǫᴜɪʀᴇᴍᴇɴᴛs

- `10 BOT-TOKENS`

- `OWNER-ID`


# ꜱᴜᴘᴘᴏʀᴛ ✨
<a href="https://t.me/thebeatoffgc"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
